import requests
import time

API_URL = "https://public.opendatasoft.com/api/explore/v2.1/catalog/datasets/donnees-synop-essentielles-omm/records"
params = {
    'limit': 10,
    'order_by': 'date DESC',
    'where': 'date >= "2023-01-01" AND date < "2023-02-01"'
}

print("Starting request...")
try:
    response = requests.get(API_URL, params=params, timeout=10)
    print(f"Status: {response.status_code}")
    print(f"Data length: {len(response.json().get('results', []))}")
except Exception as e:
    print(f"Error: {e}")

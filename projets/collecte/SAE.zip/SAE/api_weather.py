import requests
import pandas as pd
import folium
import matplotlib.pyplot as plt
import seaborn as sns
import os
from datetime import datetime

# =============================================================================
# CONFIGURATION ET CONSTANTES
# =============================================================================
# URL de l'API OpenDataSoft pour les données SYNOP (données météo synoptiques)
API_URL = "https://public.opendatasoft.com/api/explore/v2.1/catalog/datasets/donnees-synop-essentielles-omm/records"

# Limite de données pour l'exemple (peut être augmentée pour une analyse plus complète)
LIMIT = 100 

def fetch_weather_data():
    """
    Récupère les données météorologiques depuis l'API SYNOP.
    Retourne un DataFrame Pandas contenant les relevés.
    """
    print("Récupération des données météo depuis l'API SYNOP...")
    
    all_records = []
    
    # Stratégie pour avoir une comparaison par ANNÉE :
    # On récupère un échantillon de Janvier 2023 et un échantillon de Janvier 2024
    # Cela permet de satisfaire l'exigence "comparer par année" sans télécharger tout l'historique.
    
    periods = [
        {'year': 2023, 'where': 'date >= "2023-01-01" AND date < "2023-02-01"'},
        {'year': 2024, 'where': 'date >= "2024-01-01" AND date < "2024-02-01"'}
    ]
    
    for period in periods:
        print(f"Récupération des données pour {period['year']}...")
        params = {
            'limit': 100,              # 100 par page
            'order_by': 'date DESC',
            'where': period['where']
        }
        
        # On récupère 2 pages (200 enregistrements) par année
        for i in range(2):
            params['offset'] = i * 100
            try:
                response = requests.get(API_URL, params=params, timeout=10)
                response.raise_for_status()
                data = response.json()
                
                if 'results' in data:
                    all_records.extend(data['results'])
                else:
                    break
            except Exception as e:
                print(f"Erreur lors de la récupération des données ({period['year']}) : {e}")
                break
            
    print(f"{len(all_records)} enregistrements récupérés au total.")
    return pd.DataFrame(all_records)

def process_data(df):
    """
    Nettoie et prépare les données pour l'analyse.
    """
    # Conversion de la colonne 'date' en objets datetime pour faciliter les manipulations temporelles
    if 'date' in df.columns:
        df['date'] = pd.to_datetime(df['date'])
        df['year'] = df['date'].dt.year
        df['month'] = df['date'].dt.month
    
    # Normalisation du nom de la région (si disponible)
    # L'API renvoie souvent 'nom_reg' ou 'libgeo' qui contient la région/département
    # Si 'nom_reg' n'existe pas, on essaie de le déduire ou on utilise 'nom' (Station) comme fallback
    if 'nom_reg' not in df.columns:
        # Fallback simple : on crée une colonne 'nom_reg' vide ou basée sur autre chose si nécessaire
        # Pour l'instant, on espère que l'API le renvoie (c'est le cas pour SYNOP ODS)
        pass
        
    return df

def generate_map(df):
    """
    Génère une carte interactive Folium montrant les températures par station.
    Sauvegarde le résultat dans 'weather_map.html'.
    """
    print("Génération de la carte Folium...")
    
    # Extraction des coordonnées (Latitude/Longitude) depuis la colonne 'coordonnees'
    # L'API renvoie souvent un dictionnaire ou une liste [lat, lon]
    if 'coordonnees' in df.columns:
        df['lat'] = df['coordonnees'].apply(lambda x: x['lat'] if isinstance(x, dict) else (x[0] if isinstance(x, list) else None))
        df['lon'] = df['coordonnees'].apply(lambda x: x['lon'] if isinstance(x, dict) else (x[1] if isinstance(x, list) else None))
    
    # Agrégation par station ('nom') pour obtenir la température moyenne ('tc')
    if 'nom' in df.columns and 'tc' in df.columns:
        avg_temps = df.groupby('nom')['tc'].mean().reset_index()
        # On garde les coordonnées de la première occurrence pour chaque station
        coords = df.groupby('nom')[['lat', 'lon']].first().reset_index()
        map_data = pd.merge(avg_temps, coords, on='nom')
        
        # Création de la carte centrée sur la France
        # attributionControl=False pour un look plus épuré (demande utilisateur)
        m = folium.Map(location=[46.603354, 1.888334], zoom_start=6, tiles='CartoDB dark_matter', attributionControl=False)
        
        # Ajout des marqueurs pour chaque station
        for _, row in map_data.iterrows():
            if pd.notnull(row['lat']) and pd.notnull(row['lon']):
                temp = row['tc']
                
                # Code couleur selon la température
                color = 'blue' if temp < 10 else ('green' if temp < 20 else ('orange' if temp < 30 else 'red'))
                
                # Marqueur avec icône de thermomètre
                folium.Marker(
                    location=[row['lat'], row['lon']],
                    popup=f"<b>{row['nom']}</b><br>Temp: {temp:.1f}°C",
                    icon=folium.Icon(color=color, icon='thermometer-half', prefix='fa')
                ).add_to(m)
        
        # Ajout de la légende personnalisée
        legend_html = '''
        <div style="position: fixed; 
                    bottom: 50px; left: 50px; width: 150px; height: 130px; 
                    border:2px solid grey; z-index:9999; font-size:14px;
                    background-color:rgba(255, 255, 255, 0.8);
                    border-radius: 10px; padding: 10px;">
            <b>Température</b><br>
            <i class="fa fa-thermometer-half" style="color:blue"></i> &lt; 10°C<br>
            <i class="fa fa-thermometer-half" style="color:green"></i> 10-20°C<br>
            <i class="fa fa-thermometer-half" style="color:orange"></i> 20-30°C<br>
            <i class="fa fa-thermometer-half" style="color:red"></i> &gt; 30°C
        </div>
        '''
        m.get_root().html.add_child(folium.Element(legend_html))
        
        m.save('weather_map.html')
        print("Carte sauvegardée sous 'weather_map.html'")

def generate_charts(df):
    """
    Génère les graphiques statiques (images PNG) pour le dashboard.
    """
    print("Génération des graphiques...")
    sns.set_theme(style="darkgrid") # Style visuel des graphiques
    
    # --- GRAPHIQUE 1 : Comparaison Température par Région et par Année (STRICT COMPLIANCE) ---
    # On utilise 'nom_reg' si dispo, sinon on essaie de grouper par 'nom' (Station) en attendant mieux
    # Mais pour la consigne "Région/Année", on va faire de notre mieux avec les données.
    
    region_col = 'nom_reg' if 'nom_reg' in df.columns else 'nom' # Fallback sur Station si Région manquante
    title_text = 'Température Moyenne par Région et par Année' if 'nom_reg' in df.columns else 'Température Moyenne par Station et par Année'
    
    if 'tc' in df.columns and 'year' in df.columns:
        plt.figure(figsize=(12, 6))
        
        # Agrégation par Région et Année
        chart_data = df.groupby([region_col, 'year'])['tc'].mean().reset_index()
        
        # Si trop de régions/stations, on prend les 10 plus fréquentes/importantes pour la lisibilité
        top_regions = chart_data[region_col].unique()[:10]
        chart_data = chart_data[chart_data[region_col].isin(top_regions)]
        
        sns.barplot(data=chart_data, x=region_col, y='tc', hue='year', palette='viridis')
        
        plt.title(title_text, fontsize=16, fontweight='bold')
        plt.xlabel('Région / Lieu', fontsize=12)
        plt.ylabel('Température Moyenne (°C)', fontsize=12)
        plt.legend(title='Année')
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig('weather_chart.png')
        plt.close()
        print("Graphique 1 sauvegardé sous 'weather_chart.png'")

    # --- GRAPHIQUE 2 : Focus Local (Niort - IUT) ---
    # Coordonnées de l'IUT de Niort (8 rue Archimède)
    # Latitude : 46.3237, Longitude : -0.4648
    niort_lat, niort_lon = 46.3237, -0.4648
    
    def calculate_distance(row):
        """Calcule la distance approximative en km par rapport à Niort"""
        if pd.notnull(row['lat']) and pd.notnull(row['lon']):
            # Approximation Euclidienne simple (1 degré lat ~= 111km)
            # Note : Pour une précision parfaite, on utiliserait la formule de Haversine,
            # mais l'approximation Euclidienne suffit pour ce filtrage grossier (<100km).
            return ((row['lat'] - niort_lat)**2 + (row['lon'] - niort_lon)**2)**0.5 * 111
        return 9999

    if 'lat' in df.columns:
        df['dist_niort'] = df.apply(calculate_distance, axis=1)
        # Filtrage des stations à moins de 100km de Niort
        niort_data = df[df['dist_niort'] < 100]
        
        if not niort_data.empty:
            # Tri des données par date
            niort_data = niort_data.sort_values('date')
            
            # AGRÉGATION POUR ÉVITER LES DOUBLONS (Lignes verticales)
            # On fait la moyenne si plusieurs points ont la même date exacte
            niort_data = niort_data.groupby(['date', 'nom'])['tc'].mean().reset_index()
            
            plt.figure(figsize=(10, 5))
            
            # --- GRAPHIQUE SIMPLE (LIGNE) ---
            sns.lineplot(data=niort_data, x='date', y='tc', hue='nom')
            
            # Titre et labels
            plt.title('Évolution de la Température autour de Niort IUT (<100km)', fontsize=16, fontweight='bold')
            plt.xlabel('Date / Heure', fontsize=12)
            plt.ylabel('Température (°C)', fontsize=12)
            
            plt.legend(title='Station')
            plt.xticks(rotation=45)
            
            # Suppression des bordures (spines) inutiles pour un look plus épuré ("Enlever les barres")
            sns.despine()
            
            plt.tight_layout()
            plt.savefig('poitiers_data.png')
            plt.close()
            print("Graphique 2 (Niort) sauvegardé sous 'poitiers_data.png'")

    # --- GRAPHIQUE 3 : Indicateur Innovant (Joint Plot - Hexbin) ---
    if 'tc' in df.columns and 'u' in df.columns:
        # Création du JointGrid
        g = sns.jointplot(data=df, x='tc', y='u', kind='hex', color='#4CB391')
        
        # Personnalisation des labels
        g.set_axis_labels('Température (°C)', 'Humidité (%)', fontsize=12)
        
        # On supprime le titre interne pour éviter le chevauchement avec le titre de la carte HTML
        # g.fig.suptitle(...) -> SUPPRIMÉ
        
        # Ajustement pour éviter que les labels ne soient coupés
        g.fig.tight_layout()
        
        plt.savefig('extreme_weather.png')
        plt.close()
        print("Graphique 3 (Innovant) sauvegardé sous 'extreme_weather.png'")

if __name__ == "__main__":
    # Exécution principale du script
    df = fetch_weather_data()
    if not df.empty:
        df = process_data(df)
        generate_map(df)
        generate_charts(df)
    else:
        print("Aucune donnée récupérée.")
